package com.example.basedatosfbase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    EditText nom, ape, cor, pass;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nom = findViewById(R.id.nombre);
        ape = findViewById(R.id.apellido);
        cor = findViewById(R.id.correo);
        pass = findViewById(R.id.contraseña);

        inicializarfirebase();
    }

    private void inicializarfirebase() {
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    public void guardar(View view){
        String n = nom.getText().toString();
        String a = ape.getText().toString();
        String c = cor.getText().toString();
        String pa = pass.getText().toString();

        Persona p = new Persona();
        p.setUid(UUID.randomUUID().toString());
        p.setNombr(n);
        p.setApellido(a);
        p.setCorreo(c);
        p.setPassword(pa);
        databaseReference.child("Persona").child(p.getUid()).setValue(p);
        Toast.makeText(this, "Agregado",Toast.LENGTH_LONG).show();
        limpiar();
    }

    private void limpiar() {
        nom.setText("");
        ape.setText("");
        cor.setText("");
        pass.setText("");
    }
}