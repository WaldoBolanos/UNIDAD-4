package com.example.basedatosfbase;

public class Persona {

    private String uid;
    private String Nombr;
    private String Apellido;
    private String Correo;
    private String Password;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getNombr() {
        return Nombr;
    }

    public void setNombr(String nombr) {
        Nombr = nombr;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String apellido) {
        Apellido = apellido;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}
